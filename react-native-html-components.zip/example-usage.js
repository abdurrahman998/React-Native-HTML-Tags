import React from 'react';
import { ScrollView } from 'react-native';
import { 
  Div, 
  H1, 
  H2, 
  P, 
  Button, 
  Input, 
  Ul, 
  Li, 
  A, 
  Img, 
  Card,
  Strong,
  Em 
} from './html-components';

export default function ExampleUsage() {
  return (
    <ScrollView className="flex-1 bg-gray-50">
      <Card>
        <H1 className="text-center mb-4">Welcome to HTML-like Components</H1>
        
        <P className="mb-4">
          This is a <Strong>paragraph</Strong> with <Em>emphasized text</Em> using 
          HTML-like components in React Native.
        </P>
        
        <H2 className="mb-2">Features List</H2>
        <Ul className="mb-4">
          <Li>Semantic HTML-like components</Li>
          <Li>Tailwind CSS className support</Li>
          <Li>Native React Native performance</Li>
          <Li>Easy to use and customize</Li>
        </Ul>
        
        <Input 
          className="border border-gray-300 p-3 rounded mb-4" 
          placeholder="Enter your text here..."
        />
        
        <Button 
          className="bg-blue-500 p-3 rounded"
          onPress={() => console.log('Button pressed!')}
        >
          <P className="text-white text-center font-semibold">Press Me</P>
        </Button>
        
        <A href="https://reactnative.dev" className="mt-4 text-center">
          Learn more about React Native
        </A>
      </Card>
    </ScrollView>
  );
}
