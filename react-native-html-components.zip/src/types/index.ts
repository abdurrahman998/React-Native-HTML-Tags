import type React from "react"
import type { ViewProps, TextProps, TextInputProps, PressableProps, ImageProps } from "react-native"

// Base component props
export interface BaseViewProps extends ViewProps {
  className?: string
}

export interface BaseTextProps extends TextProps {
  className?: string
}

export interface BaseInputProps extends TextInputProps {
  className?: string
}

export interface BasePressableProps extends PressableProps {
  className?: string
}

export interface BaseImageProps extends ImageProps {
  className?: string
}

// Specific component props
export interface HeadingProps extends BaseTextProps {
  level?: 1 | 2 | 3 | 4 | 5 | 6
}

export interface ListItemProps extends BaseTextProps {
  ordered?: boolean
  index?: number
}

export interface LinkProps extends BasePressableProps {
  href?: string
  children: React.ReactNode
}

export interface SpacerProps extends BaseViewProps {
  height?: number
  width?: number
}

export interface ButtonProps extends BasePressableProps {
  children: React.ReactNode
}

export interface InputProps extends BaseInputProps {}

export interface TextareaProps extends BaseInputProps {
  multiline?: boolean
}
