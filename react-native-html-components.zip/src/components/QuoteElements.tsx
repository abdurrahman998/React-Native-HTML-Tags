import type React from "react"
import { View, Text } from "react-native"
import type { BaseViewProps, BaseTextProps } from "../types"

export const Blockquote: React.FC<BaseViewProps> = ({ className = "", style, children, ...props }) => (
  <View className={`border-l-4 border-gray-400 pl-4 my-2 ${className}`} style={style} {...props}>
    {children}
  </View>
)

export const Q: React.FC<BaseTextProps> = ({ className = "", style, children, ...props }) => (
  <Text className={className} style={style} {...props}>
    "{children}"
  </Text>
)

export const Cite: React.FC<BaseTextProps> = ({ className = "", style, children, ...props }) => (
  <Text className={`italic ${className}`} style={style} {...props}>
    {children}
  </Text>
)
