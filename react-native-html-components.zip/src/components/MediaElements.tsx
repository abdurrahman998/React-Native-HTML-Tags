import type React from "react"
import { View, Image } from "react-native"
import type { BaseViewProps, BaseImageProps } from "../types"

export const Img: React.FC<BaseImageProps> = ({ className = "", style, ...props }) => (
  <Image className={className} style={style} {...props} />
)

export const Video: React.FC<BaseViewProps> = ({ className = "", style, children, ...props }) => (
  <View className={className} style={style} {...props}>
    {children}
  </View>
)

export const Audio: React.FC<BaseViewProps> = ({ className = "", style, children, ...props }) => (
  <View className={className} style={style} {...props}>
    {children}
  </View>
)
