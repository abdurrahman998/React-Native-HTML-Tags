import type React from "react"
import { View } from "react-native"
import type { BaseViewProps } from "../types"

export const Div: React.FC<BaseViewProps> = ({ className = "", style, children, ...props }) => (
  <View className={className} style={style} {...props}>
    {children}
  </View>
)

export const Section: React.FC<BaseViewProps> = Div
export const Article: React.FC<BaseViewProps> = Div
export const Aside: React.FC<BaseViewProps> = Div
export const Header: React.FC<BaseViewProps> = Div
export const Footer: React.FC<BaseViewProps> = Div
export const Main: React.FC<BaseViewProps> = Div
export const Nav: React.FC<BaseViewProps> = Div
export const Figure: React.FC<BaseViewProps> = Div
