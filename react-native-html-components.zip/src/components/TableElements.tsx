import type React from "react"
import { View, Text } from "react-native"
import type { BaseViewProps, BaseTextProps } from "../types"

export const Table: React.FC<BaseViewProps> = ({ className = "", style, children, ...props }) => (
  <View className={`border border-gray-300 ${className}`} style={style} {...props}>
    {children}
  </View>
)

export const Thead: React.FC<BaseViewProps> = ({ className = "", style, children, ...props }) => (
  <View className={`bg-gray-100 ${className}`} style={style} {...props}>
    {children}
  </View>
)

export const Tbody: React.FC<BaseViewProps> = ({ className = "", style, children, ...props }) => (
  <View className={className} style={style} {...props}>
    {children}
  </View>
)

export const Tr: React.FC<BaseViewProps> = ({ className = "", style, children, ...props }) => (
  <View className={`flex-row border-b border-gray-200 ${className}`} style={style} {...props}>
    {children}
  </View>
)

export const Th: React.FC<BaseTextProps> = ({ className = "", style, children, ...props }) => (
  <Text className={`flex-1 p-2 font-bold ${className}`} style={style} {...props}>
    {children}
  </Text>
)

export const Td: React.FC<BaseTextProps> = ({ className = "", style, children, ...props }) => (
  <Text className={`flex-1 p-2 ${className}`} style={style} {...props}>
    {children}
  </Text>
)
