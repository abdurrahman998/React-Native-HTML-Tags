import type React from "react"
import { Text, TouchableOpacity, Linking } from "react-native"
import type { LinkProps } from "../types"

export const A: React.FC<LinkProps> = ({ className = "", style, children, href, onPress, ...props }) => {
  const handlePress = () => {
    if (onPress) {
      onPress()
    } else if (href) {
      Linking.openURL(href)
    }
  }

  return (
    <TouchableOpacity onPress={handlePress} {...props}>
      <Text className={`text-blue-600 underline ${className}`} style={style}>
        {children}
      </Text>
    </TouchableOpacity>
  )
}
