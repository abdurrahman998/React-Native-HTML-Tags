import type React from "react"
import { View, Text } from "react-native"
import type { BaseViewProps, BaseTextProps, ListItemProps } from "../types"

export const Ul: React.FC<BaseViewProps> = ({ className = "", style, children, ...props }) => (
  <View className={className} style={style} {...props}>
    {children}
  </View>
)

export const Ol: React.FC<BaseViewProps> = ({ className = "", style, children, ...props }) => (
  <View className={className} style={style} {...props}>
    {children}
  </View>
)

export const Li: React.FC<ListItemProps> = ({
  className = "",
  style,
  children,
  ordered = false,
  index = 0,
  ...props
}) => (
  <Text className={`ml-4 ${className}`} style={style} {...props}>
    {ordered ? `${index + 1}. ` : "• "}
    {children}
  </Text>
)

export const Dl: React.FC<BaseViewProps> = ({ className = "", style, children, ...props }) => (
  <View className={className} style={style} {...props}>
    {children}
  </View>
)

export const Dt: React.FC<BaseTextProps> = ({ className = "", style, children, ...props }) => (
  <Text className={`font-semibold ${className}`} style={style} {...props}>
    {children}
  </Text>
)

export const Dd: React.FC<BaseTextProps> = ({ className = "", style, children, ...props }) => (
  <Text className={`ml-4 ${className}`} style={style} {...props}>
    {children}
  </Text>
)
