import type React from "react"
import { View, Text, ScrollView } from "react-native"
import type { BaseViewProps, SpacerProps } from "../types"

export const Br: React.FC = () => <Text>{"\n"}</Text>

export const Hr: React.FC<BaseViewProps> = ({ className = "", style, ...props }) => (
  <View className={`border-b border-gray-300 my-2 ${className}`} style={style} {...props} />
)

export const Pre: React.FC<BaseViewProps> = ({ className = "", style, children, ...props }) => (
  <ScrollView horizontal className={className} style={style} {...props}>
    <Text className="font-mono bg-gray-100 p-2">{children}</Text>
  </ScrollView>
)

export const Container: React.FC<BaseViewProps> = ({ className = "", style, children, ...props }) => (
  <View className={`px-4 ${className}`} style={style} {...props}>
    {children}
  </View>
)

export const Spacer: React.FC<SpacerProps> = ({ height = 16, width = 0, className = "", style }) => (
  <View className={className} style={[{ height, width }, style]} />
)

export const Card: React.FC<BaseViewProps> = ({ className = "", style, children, ...props }) => (
  <View className={`bg-white rounded-lg shadow-md p-4 m-2 ${className}`} style={style} {...props}>
    {children}
  </View>
)
