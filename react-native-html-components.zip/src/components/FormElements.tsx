import type React from "react"
import { View, Text, TextInput, Pressable } from "react-native"
import type { BaseViewProps, BaseTextProps, InputProps, TextareaProps, ButtonProps } from "../types"

export const Form: React.FC<BaseViewProps> = ({ className = "", style, children, ...props }) => (
  <View className={className} style={style} {...props}>
    {children}
  </View>
)

export const Fieldset: React.FC<BaseViewProps> = ({ className = "", style, children, ...props }) => (
  <View className={`border border-gray-300 p-4 ${className}`} style={style} {...props}>
    {children}
  </View>
)

export const Legend: React.FC<BaseTextProps> = ({ className = "", style, children, ...props }) => (
  <Text className={`font-semibold ${className}`} style={style} {...props}>
    {children}
  </Text>
)

export const Input: React.FC<InputProps> = ({ className = "", style, ...props }) => (
  <TextInput className={className} style={style} {...props} />
)

export const Textarea: React.FC<TextareaProps> = ({ className = "", style, multiline = true, ...props }) => (
  <TextInput className={className} style={style} multiline={multiline} {...props} />
)

export const Label: React.FC<BaseTextProps> = ({ className = "", style, children, ...props }) => (
  <Text className={className} style={style} {...props}>
    {children}
  </Text>
)

export const Button: React.FC<ButtonProps> = ({ className = "", style, children, onPress, ...props }) => (
  <Pressable className={className} style={style} onPress={onPress} {...props}>
    {children}
  </Pressable>
)
