import type React from "react"
import { Text } from "react-native"
import type { BaseTextProps } from "../types"

export const H1: React.FC<BaseTextProps> = ({ className = "", style, children, ...props }) => (
  <Text className={`text-4xl font-bold ${className}`} style={style} {...props}>
    {children}
  </Text>
)

export const H2: React.FC<BaseTextProps> = ({ className = "", style, children, ...props }) => (
  <Text className={`text-3xl font-bold ${className}`} style={style} {...props}>
    {children}
  </Text>
)

export const H3: React.FC<BaseTextProps> = ({ className = "", style, children, ...props }) => (
  <Text className={`text-2xl font-semibold ${className}`} style={style} {...props}>
    {children}
  </Text>
)

export const H4: React.FC<BaseTextProps> = ({ className = "", style, children, ...props }) => (
  <Text className={`text-xl font-semibold ${className}`} style={style} {...props}>
    {children}
  </Text>
)

export const H5: React.FC<BaseTextProps> = ({ className = "", style, children, ...props }) => (
  <Text className={`text-lg font-medium ${className}`} style={style} {...props}>
    {children}
  </Text>
)

export const H6: React.FC<BaseTextProps> = ({ className = "", style, children, ...props }) => (
  <Text className={`text-base font-medium ${className}`} style={style} {...props}>
    {children}
  </Text>
)

export const P: React.FC<BaseTextProps> = ({ className = "", style, children, ...props }) => (
  <Text className={`text-base ${className}`} style={style} {...props}>
    {children}
  </Text>
)

export const Span: React.FC<BaseTextProps> = ({ className = "", style, children, ...props }) => (
  <Text className={className} style={style} {...props}>
    {children}
  </Text>
)

export const Strong: React.FC<BaseTextProps> = ({ className = "", style, children, ...props }) => (
  <Text className={`font-bold ${className}`} style={style} {...props}>
    {children}
  </Text>
)

export const Em: React.FC<BaseTextProps> = ({ className = "", style, children, ...props }) => (
  <Text className={`italic ${className}`} style={style} {...props}>
    {children}
  </Text>
)

export const Small: React.FC<BaseTextProps> = ({ className = "", style, children, ...props }) => (
  <Text className={`text-sm ${className}`} style={style} {...props}>
    {children}
  </Text>
)

export const Mark: React.FC<BaseTextProps> = ({ className = "", style, children, ...props }) => (
  <Text className={`bg-yellow-200 ${className}`} style={style} {...props}>
    {children}
  </Text>
)

export const Code: React.FC<BaseTextProps> = ({ className = "", style, children, ...props }) => (
  <Text className={`font-mono bg-gray-100 px-1 ${className}`} style={style} {...props}>
    {children}
  </Text>
)

export const Figcaption: React.FC<BaseTextProps> = ({ className = "", style, children, ...props }) => (
  <Text className={`text-sm text-gray-600 ${className}`} style={style} {...props}>
    {children}
  </Text>
)
