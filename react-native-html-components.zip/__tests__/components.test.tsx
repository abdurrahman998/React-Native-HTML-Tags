import { render } from "@testing-library/react-native"
import { Div, H1, P, Button } from "../src"
import jest from "jest" // Import jest to fix the undeclared variable error

describe("React Native HTML Components", () => {
  test("renders Div component", () => {
    const { getByTestId } = render(<Div testID="test-div">Test content</Div>)
    expect(getByTestId("test-div")).toBeTruthy()
  })

  test("renders H1 component with correct text", () => {
    const { getByText } = render(<H1>Test Heading</H1>)
    expect(getByText("Test Heading")).toBeTruthy()
  })

  test("renders P component with correct text", () => {
    const { getByText } = render(<P>Test paragraph</P>)
    expect(getByText("Test paragraph")).toBeTruthy()
  })

  test("Button component handles press events", () => {
    const mockPress = jest.fn()
    const { getByTestId } = render(
      <Button testID="test-button" onPress={mockPress}>
        <P>Press me</P>
      </Button>,
    )

    const button = getByTestId("test-button")
    expect(button).toBeTruthy()
  })

  test("components accept className prop", () => {
    const { getByTestId } = render(
      <Div testID="styled-div" className="bg-blue-500 p-4">
        Styled content
      </Div>,
    )

    const styledDiv = getByTestId("styled-div")
    expect(styledDiv.props.className).toBe("bg-blue-500 p-4")
  })
})
