import jest from "jest"
import "@testing-library/jest-native/extend-expect"

// Mock React Native modules
jest.mock("react-native", () => {
  const RN = jest.requireActual("react-native")

  RN.Linking = {
    openURL: jest.fn(() => Promise.resolve()),
  }

  return RN
})
