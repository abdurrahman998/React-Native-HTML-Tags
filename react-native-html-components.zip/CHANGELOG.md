# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2024-01-XX

### Added
- Initial release of React Native HTML Components
- Complete set of HTML-like components for React Native
- TypeScript support with comprehensive type definitions
- Tailwind CSS className support
- Semantic HTML elements (Header, Footer, Main, Section, Article, etc.)
- Form components (Input, Textarea, Button, Form, Fieldset, Legend)
- List components (Ul, Ol, Li, Dl, Dt, Dd)
- Table components (Table, Thead, Tbody, Tr, Th, Td)
- Text components (H1-H6, P, Span, Strong, Em, Small, Mark, Code)
- Media components (Img, Video, Audio)
- Interactive components (A with link support)
- Utility components (Br, Hr, Card, Container, Spacer)
- Quote components (Blockquote, Q, Cite)
- Jest testing setup
- ESLint configuration
- Rollup build configuration
- Comprehensive documentation
